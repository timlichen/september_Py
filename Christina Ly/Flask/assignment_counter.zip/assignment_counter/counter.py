from flask import Flask, render_template, request, redirect, session
app = Flask(__name__)
app.secret_key = 'Secret'
@app.route('/')
def index():
	session['count'] = 0
	return redirect('/show')
@app.route('/show')
def show_count():
	session['count']+=1
	return render_template('index.html')
@app.route('/double')
def double_count():
	session['count']+=1
	return redirect('/show')
app.run(debug = True)