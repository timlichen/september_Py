from __future__ import unicode_literals

from django.apps import AppConfig


class SemiRestfulConfig(AppConfig):
    name = 'semi_restful'
